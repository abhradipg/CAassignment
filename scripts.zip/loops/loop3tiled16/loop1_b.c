#include <stdio.h>
#include <stdlib.h>
#include "papi.h" /* This needs to be included every time you use PAPI */

#define NUM_EVENTS 5
#define ERROR_RETURN(retval) { fprintf(stderr, "Error %d %s:line %d: \n", retval,__FILE__,__LINE__);  exit(retval); }
#define size 2048
#define tile 16
int matA[size][size],matB[size][size],matC[size][size];
int main()
{
   int EventSet = PAPI_NULL;
   /*must be initialized to PAPI_NULL before calling PAPI_create_event*/
   long long values[NUM_EVENTS];
   /*This is where we store the values we read from the eventset */
    
   /* We use number to keep track of the number of events in the EventSet */ 
   int retval, number;
   /* Event codes*/
   int event_codes[NUM_EVENTS]={PAPI_L1_LDM,PAPI_L1_STM,PAPI_L1_TCM,PAPI_L1_DCM,PAPI_L1_ICM};

   char errstring[PAPI_MAX_STR_LEN];
   
   /*initializing matrices*/
   for(int i=0;i<size;i++){
      for(int j=0;j<size;j++){
      matA[i][j]=0;
      matB[i][j]=0;
      matC[i][j]=0;
   }
   }

   /*************************************************************************** 
   *  This part initializes the library and compares the version number of the*
   * header file, to the version of the library, if these don't match then it *
   * is likely that PAPI won't work correctly.If there is an error, retval    *
   * keeps track of the version number.                                       *
   ***************************************************************************/

   if((retval = PAPI_library_init(PAPI_VER_CURRENT)) != PAPI_VER_CURRENT )
      ERROR_RETURN(retval);
     
   /* Creating the eventset */              
   if ( (retval = PAPI_create_eventset(&EventSet)) != PAPI_OK)
      ERROR_RETURN(retval);

   /* Add the array of events PAPI_TOT_INS and PAPI_TOT_CYC to the eventset*/
	if ((retval=PAPI_add_events(EventSet, event_codes, NUM_EVENTS)) != PAPI_OK)
		ERROR_RETURN(retval);

   /* Start counting */

   if ( (retval = PAPI_start(EventSet)) != PAPI_OK)
      ERROR_RETURN(retval);
   
   /* you can replace your code here */
   
   for(int k=0;k<size;k+=tile){
        for(int i=0;i<size;i+=tile){
            for(int j=0;j<size;j+=tile){
                for(int kk=k;kk<k+tile;kk++)
                for(int ii=i;ii<i+tile;ii++)
                for(int jj=j;jj<j+tile;jj++)
                    matC[ii][jj]+=(matA[ii][kk]*matB[kk][jj]);
            }
        }
    }

   /* Stop counting and store the values into the array */
   if ( (retval = PAPI_stop(EventSet, values)) != PAPI_OK)
      ERROR_RETURN(retval);

   /*write output to file*/
   FILE *fPtr;
   fPtr = fopen("loop1.txt", "a");
   fprintf(fPtr,"total l1 load misses %lld \n", values[0] );
   fprintf(fPtr,"total l1 store misses %lld \n",values[1]);
   fprintf(fPtr,"total l1 total misses %lld \n",values[2]);
   fprintf(fPtr,"total l1 data misses %lld \n",values[3]);
   fprintf(fPtr,"total l1 instruction misses %lld \n",values[4]);
   fclose(fPtr);

   /* free the resources used by PAPI */
   PAPI_shutdown();
 
   exit(0);
}
