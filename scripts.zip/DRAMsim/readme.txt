custom_ddr4_8_8_2666.ini is used to implement row interleaving
custom_ddr4_8_8_2666v2.ini is used to implement column interleaving

replace command_queue.cc and command_queue.h and bank_state.cc files in src folder in dramsim3 and uncomment appropriate function to implement different scheduling policies
